package com.vibemusic.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import com.vibemusic.app.VibeMusicApp
import com.vibemusic.app.data.MusicRepository
import com.vibemusic.app.data.model.Album
import com.vibemusic.app.data.model.Artist
import com.vibemusic.app.data.model.MountConfig
import com.vibemusic.app.data.model.Playlist
import com.vibemusic.app.data.model.Track
import com.vibemusic.app.playback.PlayerHub
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Unified ViewModel — drives all root screens (QuickPicks, Songs, Playlists,
 * Artists, Albums) and detail screens.
 */
class MusicViewModel(
    private val repo: MusicRepository = MusicRepository()
) : ViewModel() {

    // ─── Track flows ─────────────────────────────────────────────────

    /** All tracks (local + network). */
    val allTracks: StateFlow<List<Track>> =
        repo.observeTracks().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    /** Recent / "Quick picks" — most recently added. */
    val recent: StateFlow<List<Track>> =
        repo.observeTracks().map { it.sortedByDescending { t -> t.id.hashCode() }.take(20) }
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    /** User-marked favorites. */
    val favorites: StateFlow<List<Track>> =
        repo.observeTracks().map { it.filter { t -> t.isFavorite } }
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    /** Grouped by album. */
    val albums: StateFlow<List<Album>> =
        repo.observeTracks().map { tracks ->
            tracks.filter { it.album != "Unknown Album" }
                .groupBy { it.albumId }
                .map { (id, ts) ->
                    val first = ts.first()
                    Album(
                        id = id, title = first.album, artist = first.artist,
                        year = first.year, trackCount = ts.size,
                        artUri = first.albumArtUri, sourceType = first.sourceType,
                    )
                }
                .sortedBy { it.title }
        }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    /** Grouped by artist. */
    val artists: StateFlow<List<Artist>> =
        repo.observeTracks().map { tracks ->
            tracks.groupBy { it.artist }
                .map { (name, ts) ->
                    Artist(
                        name = name,
                        trackCount = ts.size,
                        albumCount = ts.map { it.album }.distinct().size,
                    )
                }
                .sortedBy { it.name }
        }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val mounts: StateFlow<List<MountConfig>> =
        repo.observeMounts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val playlists: StateFlow<List<Playlist>> =
        repo.observePlaylists().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val playback: StateFlow<com.vibemusic.app.playback.PlaybackSnapshot> = PlayerHub.state

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _snackbar = MutableSharedFlow<String>(extraBufferCapacity = 5)
    val snackbar = _snackbar.asSharedFlow()

    init {
        viewModelScope.launch { mounts.collect { PlayerHub.setMounts(it) } }
    }

    // ─── Per-album / per-artist tracks ────────────────────────────────

    fun albumTracks(albumId: String): StateFlow<List<Track>> =
        repo.observeTracks().map { it.filter { t -> t.albumId == albumId } }
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun artistTracks(name: String): StateFlow<List<Track>> =
        repo.observeTracks().map { it.filter { t -> t.artist == name } }
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    suspend fun getPlaylistTracks(pid: Long): List<Track> = repo.getPlaylistTracks(pid)

    // ─── Playback ────────────────────────────────────────────────────

    fun play(track: Track, queue: List<Track>) = playTrack(track, queue)
    fun playTrack(track: Track, queue: List<Track>) {
        val player = PlayerHub.player() ?: return
        val items = queue.map { it.toMediaItem() }
        val index = queue.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        player.setMediaItems(items, index, 0L)
        player.prepare()
        player.play()
    }
    fun playShuffled(queue: List<Track>) {
        if (queue.isEmpty()) return
        val shuffled = queue.shuffled()
        play(shuffled.first(), shuffled)
    }

    fun togglePP() = togglePlayPause()
    fun togglePlayPause() {
        val p = PlayerHub.player() ?: return
        if (p.isPlaying) p.pause() else p.play()
    }
    fun next() { PlayerHub.player()?.seekToNext() }
    fun prev() { PlayerHub.player()?.seekToPrevious() }
    fun previous() { PlayerHub.player()?.seekToPrevious() }
    fun seek(ms: Long) { PlayerHub.player()?.seekTo(ms) }
    fun seekTo(ms: Long) { PlayerHub.player()?.seekTo(ms) }
    fun toggleShuffle() {
        PlayerHub.player()?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }
    fun toggleRepeat() {
        PlayerHub.player()?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    // ─── Favorites ────────────────────────────────────────────────────

    fun toggleFavorite(trackId: String) = viewModelScope.launch {
        repo.toggleFavorite(trackId)
    }

    // ─── Mounts ───────────────────────────────────────────────────────

    fun upsertMount(cfg: MountConfig) {
        val withId = if (cfg.id.isBlank()) cfg.copy(id = UUID.randomUUID().toString()) else cfg
        viewModelScope.launch { repo.upsertMount(withId) }
    }
    fun addOrUpdateMount(cfg: MountConfig) = upsertMount(cfg)
    fun deleteMount(id: String) = viewModelScope.launch { repo.deleteMount(id) }
    fun scanMount(cfg: MountConfig) = viewModelScope.launch {
        _busy.value = true
        try { repo.scanMount(cfg) } finally { _busy.value = false }
    }
    fun scan(cfg: MountConfig) = scanMount(cfg)
    suspend fun testMount(cfg: MountConfig) = repo.testMount(cfg)
    suspend fun test(cfg: MountConfig) = repo.testMount(cfg)

    // ─── Local scan ───────────────────────────────────────────────────

    fun rescanLocal() = viewModelScope.launch {
        _busy.value = true
        try {
            val n = repo.scanLocal()
            _snackbar.emit("Found $n local tracks")
        } catch (e: Exception) {
            _snackbar.emit("Error: ${e.message}")
        } finally {
            _busy.value = false
        }
    }

    // ─── Playlists ────────────────────────────────────────────────────

    fun createPlaylist(name: String) = viewModelScope.launch { repo.createPlaylist(name) }
    fun addToPlaylist(pid: Long, tid: String) = viewModelScope.launch {
        repo.addToPlaylist(pid, tid)
    }
    fun removeFromPlaylist(pid: Long, tid: String) = viewModelScope.launch {
        repo.removeFromPlaylist(pid, tid)
    }
    fun deletePlaylist(id: Long) = viewModelScope.launch { repo.deletePlaylist(id) }

    // ─── MediaItem mapper ────────────────────────────────────────────

    private fun Track.toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setUri(sourceUri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(albumArtUri?.let { android.net.Uri.parse(it) })
                .build()
        )
        .build()
}
