package com.vibemusic.app.ui.screens.sleep

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vibemusic.app.data.model.Track
import com.vibemusic.app.ui.theme.*

/**
 * Musicolet-style bookmarks: save position + note for any track.
 */
data class BookmarkEntry(
    val trackId: String,
    val trackTitle: String,
    val trackArtist: String,
    val positionMs: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
)

/**
 * A simple in-memory bookmark store. For production, persist via Room.
 */
object BookmarkStore {
    private val _bookmarks = mutableStateListOf<BookmarkEntry>()
    val bookmarks: List<BookmarkEntry> get() = _bookmarks.toList()

    fun add(track: Track, positionMs: Long, note: String = "") {
        _bookmarks.removeAll { it.trackId == track.id }
        _bookmarks.add(0, BookmarkEntry(
            trackId = track.id,
            trackTitle = track.title,
            trackArtist = track.artist,
            positionMs = positionMs,
            note = note,
        ))
    }

    fun remove(trackId: String) {
        _bookmarks.removeAll { it.trackId == trackId }
    }

    fun get(trackId: String): BookmarkEntry? =
        _bookmarks.find { it.trackId == trackId }
}

@Composable
fun BookmarksScreen(onDismiss: () -> Unit) {
    val bookmarks = BookmarkStore.bookmarks

    Column(
        Modifier.fillMaxSize().background(Ink).systemBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Bookmarks & Notes", color = TextHigh,
                fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onDismiss) { Text("Close") }
        }

        if (bookmarks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.BookmarkBorder, null,
                        tint = TextLow, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("No bookmarks yet", color = TextLow)
                    Text("Long-press a track and tap Bookmark to add one",
                        color = TextLow, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(bookmarks) { bm ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = InkRaised),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Bookmark, null,
                                    tint = Secondary, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(bm.trackTitle, color = TextHigh,
                                        fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                    Text(bm.trackArtist, color = TextMid, fontSize = 12.sp)
                                }
                                Text(bm.positionMmSs(), color = TextLow, fontSize = 11.sp)
                            }
                            if (bm.note.isNotBlank()) {
                                Spacer(Modifier.height(8.dp))
                                Text(bm.note, color = TextMid, fontSize = 12.sp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(InkSurface, RoundedCornerShape(8.dp))
                                        .padding(10.dp))
                            }
                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { BookmarkStore.remove(bm.trackId) }) {
                                    Text("Delete", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun BookmarkEntry.positionMmSs(): String {
    val s = positionMs / 1000
    return "%d:%02d".format(s / 60, s % 60)
}
