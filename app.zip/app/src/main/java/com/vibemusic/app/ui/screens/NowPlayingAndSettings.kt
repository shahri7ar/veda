package com.vibemusic.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vibemusic.app.VibeMusicApp
import com.vibemusic.app.playback.PlaybackSnapshot
import com.vibemusic.app.ui.MusicViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingSheet(
    playback: PlaybackSnapshot,
    onDismiss: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onSeek: (Long) -> Unit
) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheet,
        containerColor = MaterialTheme.colorScheme.background,
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.fillMaxWidth().aspectRatio(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Album, null, tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(96.dp))
            }
            Spacer(Modifier.height(24.dp))
            Text(playback.title.ifBlank { "Nothing playing" },
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold, fontSize = 22.sp, maxLines = 1)
            Text(playback.artist,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp, maxLines = 1)
            Spacer(Modifier.height(16.dp))
            val progress =
                if (playback.durationMs > 0) playback.positionMs.toFloat() / playback.durationMs else 0f
            Slider(
                value = progress.coerceIn(0f, 1f),
                onValueChange = { v -> onSeek((v * playback.durationMs).toLong()) },
                colors = SliderDefaults.colors(
                    thumbColor = MaterialTheme.colorScheme.primary,
                    activeTrackColor = MaterialTheme.colorScheme.primary
                )
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(playback.positionMs), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                Text(fmt(playback.durationMs), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onPrev) {
                    Icon(Icons.Rounded.SkipPrevious, null,
                        modifier = Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.onBackground)
                }
                FilledIconButton(
                    onClick = onTogglePlay,
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Icon(
                        if (playback.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        null, modifier = Modifier.size(36.dp)
                    )
                }
                IconButton(onClick = onNext) {
                    Icon(Icons.Rounded.SkipNext, null,
                        modifier = Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.onBackground)
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun SettingsScreen(vm: MusicViewModel) {
    val app = VibeMusicApp.instance
    val usage by app.cacheManager.usageBytes.collectAsState()
    val maxCacheMb by app.settingsRepository.maxCacheMb.collectAsState(initial = 1024)
    val cacheOnPlay by app.settingsRepository.cacheOnPlay.collectAsState(initial = true)
    val wifiOnly by app.settingsRepository.wifiOnly.collectAsState(initial = false)
    val scope = rememberCoroutineScope()

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SectionHeader("Cache")
        SettingRow(
            title = "Cache usage",
            subtitle = "${usage / (1024 * 1024)} MB / $maxCacheMb MB"
        )
        SettingSlider(
            title = "Max cache size",
            valueMb = maxCacheMb,
            onChange = { mb ->
                scope.launch {
                    app.settingsRepository.setMaxCacheMb(mb)
                    app.cacheManager.setMaxBytes(mb.toLong() * 1024 * 1024)
                }
            }
        )
        SettingToggle("Cache while playing", cacheOnPlay) {
            scope.launch { app.settingsRepository.setCacheOnPlay(it) }
        }
        SettingToggle("Stream on Wi-Fi only", wifiOnly) {
            scope.launch { app.settingsRepository.setWifiOnly(it) }
        }
        FilledTonalButton(onClick = {
            scope.launch { app.cacheManager.clearAll() }
        }) { Text("Clear cache now") }
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SettingToggle(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}

@Composable
private fun SettingSlider(title: String, valueMb: Int, onChange: (Int) -> Unit) {
    Column {
        Text("$title: $valueMb MB", color = MaterialTheme.colorScheme.onSurface)
        Slider(
            value = valueMb.toFloat(),
            onValueChange = { onChange(it.toInt()) },
            valueRange = 128f..8192f,
            steps = 31
        )
    }
}

private fun fmt(ms: Long): String {
    if (ms <= 0) return "0:00"
    val s = ms / 1000; val m = s / 60; val r = s % 60
    return "%d:%02d".format(m, r)
}
