package com.vibemusic.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vibemusic.app.playback.PlaybackSnapshot
import com.vibemusic.app.ui.MusicViewModel
import com.vibemusic.app.ui.screens.folders.FoldersScreen
import com.vibemusic.app.ui.theme.*

/**
 * Root screen — ViMusic-style unified navigation.
 *
 * Five primary screens reachable via left labels:
 *   0 Quick picks  1 Songs  2 Playlists  3 Artists  4 Albums
 *
 * Extras (Folders, Mounts, Settings) are reachable via a hamburger menu /
 * the Settings panel — not bottom-nav anymore.
 */
@Composable
fun RootScreen(vm: MusicViewModel) {
    var currentTab by rememberSaveable { mutableIntStateOf(0) }
    var overlay by remember { mutableStateOf<Overlay?>(null) }
    val playback by vm.playback.collectAsState()

    Box(Modifier.fillMaxSize().background(Ink)) {

        // Main content — switch between root screens
        when (currentTab) {
            0 -> QuickPicksScreen(vm,
                onSearch = { overlay = Overlay.SEARCH },
                onNavigate = { currentTab = it },
            )
            1 -> SongsScreen(vm,
                onSearch = { overlay = Overlay.SEARCH },
                onNavigate = { currentTab = it },
            )
            2 -> PlaylistsScreen(vm,
                onPlay = {},
                onSearch = { overlay = Overlay.SEARCH },
                onNavigate = { currentTab = it },
            )
            3 -> ArtistsScreen(vm,
                onPlay = {},
                onSearch = { overlay = Overlay.SEARCH },
                onNavigate = { currentTab = it },
            )
            4 -> AlbumsScreen(vm,
                onPlay = {},
                onSearch = { overlay = Overlay.SEARCH },
                onNavigate = { currentTab = it },
            )
        }

        // Mini player (only when something is playing)
        AnimatedVisibility(
            visible = playback.title.isNotBlank(),
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            ViMusicMiniPlayer(
                playback = playback,
                onTogglePlay = vm::togglePP,
                onNext = vm::next,
                onClick = { overlay = Overlay.NOW_PLAYING },
            )
        }

        // Floating "extras" menu button at top-left — opens settings/mounts/folders
        IconButton(
            onClick = { overlay = Overlay.EXTRAS },
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 16.dp, top = 24.dp),
        ) {
            Icon(Icons.Rounded.Menu, null, tint = TextHigh, modifier = Modifier.size(24.dp))
        }
    }

    // Overlays
    when (overlay) {
        Overlay.NOW_PLAYING -> NowPlayingSheet(
            playback = playback,
            onDismiss = { overlay = null },
            onTogglePlay = vm::togglePP,
            onNext = vm::next,
            onPrev = vm::prev,
            onSeek = vm::seek,
        )
        Overlay.EXTRAS -> ExtrasMenu(
            onDismiss = { overlay = null },
            onMounts = { overlay = Overlay.MOUNTS },
            onFolders = { overlay = Overlay.FOLDERS },
            onSettings = { overlay = Overlay.SETTINGS },
        )
        Overlay.MOUNTS -> MountsScreen(vm, onPlay = {})
        Overlay.FOLDERS -> FoldersScreen(onBack = { overlay = null })
        Overlay.SETTINGS -> SettingsScreen(vm)
        Overlay.SEARCH -> { /* TODO global search */ }
        null -> Unit
    }
}

private enum class Overlay { NOW_PLAYING, EXTRAS, MOUNTS, FOLDERS, SETTINGS, SEARCH }

/* ─────────────── Mini player bar ─────────────── */

@Composable
private fun ViMusicMiniPlayer(
    playback: PlaybackSnapshot,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onClick: () -> Unit,
) {
    Surface(
        color = InkSurface,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        tonalElevation = 8.dp,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
    ) {
        Column {
            // Tiny progress bar at the very top of the mini-player
            if (playback.durationMs > 0) {
                val pct = (playback.positionMs.toFloat() / playback.durationMs).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = pct,
                    color = Primary,
                    trackColor = InkRaised,
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                )
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(10.dp)).background(InkRaised),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.MusicNote, null,
                        tint = Primary, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(playback.title, color = TextHigh,
                        fontWeight = FontWeight.SemiBold, maxLines = 1, fontSize = 14.sp)
                    if (playback.artist.isNotBlank()) {
                        Text(playback.artist, color = TextMid,
                            maxLines = 1, fontSize = 12.sp)
                    }
                }
                IconButton(onClick = onTogglePlay, modifier = Modifier.size(44.dp)) {
                    Icon(
                        if (playback.isPlaying) Icons.Rounded.Pause
                        else Icons.Rounded.PlayArrow,
                        null, tint = TextHigh, modifier = Modifier.size(28.dp),
                    )
                }
                IconButton(onClick = onNext, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Rounded.SkipNext, null,
                        tint = TextMid, modifier = Modifier.size(24.dp))
                }
            }
        }
    }
}

/* ─────────────── Extras menu (Mounts / Folders / Settings) ─────────────── */

@Composable
private fun ExtrasMenu(
    onDismiss: () -> Unit,
    onMounts: () -> Unit,
    onFolders: () -> Unit,
    onSettings: () -> Unit,
) {
    Box(
        Modifier.fillMaxSize()
            .background(Ink.copy(alpha = 0.92f))
            .clickable(onClick = onDismiss),
    ) {
        Column(
            Modifier
                .fillMaxWidth(0.7f)
                .align(Alignment.CenterStart)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Text("More", color = TextHigh,
                fontWeight = FontWeight.Bold, fontSize = 28.sp)

            ExtrasItem(Icons.Rounded.Folder, "Folders", onClick = onFolders)
            ExtrasItem(Icons.Rounded.Cloud, "Network mounts", onClick = onMounts)
            ExtrasItem(Icons.Rounded.Bedtime, "Sleep timer", onClick = { /* TODO */ })
            ExtrasItem(Icons.Rounded.BookmarkBorder, "Bookmarks", onClick = { /* TODO */ })
            ExtrasItem(Icons.Rounded.Equalizer, "Equalizer", onClick = { /* TODO */ })
            ExtrasItem(Icons.Rounded.Backup, "Backup & restore", onClick = { /* TODO */ })
            ExtrasItem(Icons.Rounded.Settings, "Settings", onClick = onSettings)
        }
    }
}

@Composable
private fun ExtrasItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Primary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(label, color = TextHigh,
            fontWeight = FontWeight.Medium, fontSize = 16.sp)
    }
}
