package com.vibemusic.app.ui.screens.lyrics

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vibemusic.app.data.lyrics.LrclibResponse
import com.vibemusic.app.data.lyrics.LyricsState
import com.vibemusic.app.ui.screens.formatDuration
import com.vibemusic.app.ui.theme.*

/**
 * Full-screen lyrics overlay.
 *
 * Reads its state from [viewModel.state] and renders:
 *  - Loading spinner
 *  - Synced / plain lyrics text
 *  - Search result picker list
 *  - Error with retry
 */
@Composable
fun LyricsScreen(
    viewModel: LyricsViewModel,
    artist: String,
    track: String,
    durationMs: Long,
    onDismiss: () -> Unit,
) {
    val state by viewModel.state.collectAsState()

    // Auto-fetch on first composition
    LaunchedEffect(artist, track) {
        if (state is LyricsState.Idle) {
            viewModel.fetchLyrics(artist, track, durationMs)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Ink, InkSurface)
                )
            )
            .systemBarsPadding()
    ) {
        Column(Modifier.fillMaxSize()) {
            // ── Top bar ──
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    viewModel.reset()
                    onDismiss()
                }) {
                    Icon(Icons.Rounded.KeyboardArrowDown, null,
                        tint = TextHigh, modifier = Modifier.size(32.dp))
                }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.ifBlank { "Unknown" },
                        color = TextHigh, fontWeight = FontWeight.Bold,
                        fontSize = 16.sp, maxLines = 1)
                    Text(artist.ifBlank { "Unknown Artist" },
                        color = TextMid, fontSize = 13.sp, maxLines = 1)
                }
                Text("Lyrics", color = TextLow, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
            }

            Spacer(Modifier.height(8.dp))

            // ── Content ──
            Box(Modifier.fillMaxSize()) {
                when (val s = state) {
                    is LyricsState.Idle,
                    is LyricsState.Loading -> {
                        LoadingPlaceholder()
                    }

                    is LyricsState.Success -> {
                        LyricsTextContent(
                            lines = s.lines,
                            isSynced = s.isSynced,
                        )
                    }

                    is LyricsState.SearchResults -> {
                        SearchResultsList(
                            items = s.items,
                            onSelect = { viewModel.onTrackSelected(it.id!!) },
                        )
                    }

                    is LyricsState.Error -> {
                        ErrorContent(
                            message = s.message,
                            onRetry = {
                                viewModel.fetchLyrics(artist, track, durationMs)
                            },
                        )
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────
//  Sub-composables
// ─────────────────────────────────────────────────────

@Composable
private fun LoadingPlaceholder() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Primary, strokeWidth = 3.dp)
    }
}

@Composable
private fun LyricsTextContent(lines: String, isSynced: Boolean) {
    // If synced, we strip LRC timestamps for display.
    // A production app would highlight the active line.
    val cleaned = if (isSynced) {
        lines.lines()
            .map { it.replace(Regex("\\[\\d{2}:\\d{2}\\.\\d{2}\\]"), "").trim() }
            .filter { it.isNotBlank() }
            .joinToString("\n\n")
    } else {
        lines
    }

    val scrollState = rememberScrollState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        if (isSynced) {
            Text("Synced lyrics", color = Primary,
                fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
        }
        Text(
            text = cleaned,
            color = TextHigh.copy(alpha = 0.9f),
            fontSize = 17.sp,
            lineHeight = 28.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun SearchResultsList(
    items: List<LrclibResponse>,
    onSelect: (LrclibResponse) -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text(
            "Multiple matches found. Tap one to load lyrics:",
            color = TextMid, fontSize = 13.sp,
            modifier = Modifier.padding(bottom = 12.dp),
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(items) { _, item ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(InkRaised)
                        .clickable { onSelect(item) }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Lyrics, null,
                        tint = Primary, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.trackName ?: "Unknown",
                            color = TextHigh, fontWeight = FontWeight.Medium,
                            fontSize = 14.sp, maxLines = 1)
                        Text(item.artistName ?: "Unknown",
                            color = TextMid, fontSize = 12.sp, maxLines = 1)
                    }
                    if (item.duration != null) {
                        Text(formatDuration(item.duration * 1000L),
                            color = TextLow, fontSize = 11.sp)
                    }
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Rounded.ChevronRight, null,
                        tint = TextLow, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
private fun ErrorContent(message: String, onRetry: () -> Unit) {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Rounded.ErrorOutline, null,
            tint = TextLow, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(12.dp))
        Text(message, color = TextMid, fontSize = 14.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 32.dp))
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onRetry) {
            Text("Retry")
        }
    }
}
